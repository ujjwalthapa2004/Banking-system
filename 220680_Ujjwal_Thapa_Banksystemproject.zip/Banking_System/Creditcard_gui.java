
/**
 * Write a description of class Creditcard_gui here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.awt.event.*;
import java.awt.*;
import javax.swing.*;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
public class Creditcard_gui
{
    //
    JFrame frame;
    JPanel panel;
    //JLabel are described below.
    JLabel cred_CardID,cred_IssuerBank,cred_RoyalBankOfScotlandGroup,cred_CreditLimit,cred_ClientName,cred_BankAccount,cred_InterestRate,cred_GracePeriod,cred_BalanceAmount,cred_ExpirationDate,cred_CVCNumber;
    
    //JLabel are described below.
    JTextField tfieldcred_ClientName,tfieldcred_CreditLimit,tfieldcred_CardID,tfieldcred_BankAccount,tfieldcred_IssuerBank,tfieldcred_InterestRate,tfieldcred_BalanceAmount,tfieldcred_CVCNumber,tfieldcred_GracePeriod,tfieldcred_ExpirationDate;
    
    //JButton are described below.
    JButton cred_ADDTOCREDITCARD, cred_CHANGETODEBITCARD,cred_SETCREDITLIMIT,cred_CANCELCREDITLIMIT,cred_CANCEL,cred_HOME;
    
    //Jcombobox are described below.
    JComboBox cred_Year,cred_Month,cred_Day;
    
 public Creditcard_gui(){
        frame=new JFrame("Credit Card");
        panel=new JPanel();
        frame.add(panel);
        
        //frame are added below.
        cred_RoyalBankOfScotlandGroup=new JLabel("Royal Bank of Scotland Group");
        cred_ClientName=new JLabel ("Client Name: ");
        cred_CardID= new JLabel ("CardID: ");
        cred_IssuerBank=new JLabel ("Issuer Bank: ");
        cred_BankAccount=new JLabel ("Bank Account: ");
        cred_CVCNumber=new JLabel ("CVC Number: ");
        cred_BalanceAmount=new JLabel ("Balance Amount: ");
        cred_InterestRate=new JLabel ("Interest Rate: ");
        cred_GracePeriod=new JLabel ("Grace Period: ");
        cred_ExpirationDate=new JLabel ("Expiration Date: ");
        cred_CreditLimit=new JLabel ("Credit Limit: ");
        
        //Textfield are added below.
        tfieldcred_CardID = new JTextField();
        tfieldcred_IssuerBank = new JTextField();
        tfieldcred_BalanceAmount = new JTextField();
        tfieldcred_BankAccount = new JTextField();
        tfieldcred_ClientName = new JTextField();
        tfieldcred_CVCNumber = new JTextField();
        tfieldcred_InterestRate = new JTextField();
        tfieldcred_GracePeriod = new JTextField();
        tfieldcred_CreditLimit = new JTextField();
        
        //JButton are added below.
        cred_ADDTOCREDITCARD = new JButton("ADD TO CREDITCARD ");
        cred_CANCEL = new JButton("CANCEL");
        cred_SETCREDITLIMIT = new JButton("SET CREDIT LIMITt");
        cred_CANCELCREDITLIMIT = new JButton("CANCEL CREDIT LIMIT");
        cred_CHANGETODEBITCARD = new JButton("CHANGE TO DEBITCARD");
        cred_HOME=new JButton("HOME");
        
        //Integer and String are added to ComboBox below.
        Integer Byear[] = {2011,2012,2013,2014,2015,2016,2017,2018,2019,2020,2021,2022,2023};
        String Bmonth[] = {"January","Febuary","March","April","May","June","July","August","September","October",
        "November","December"};
        Integer Bday[] = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30};
        
        cred_Year = new JComboBox(Byear);
        cred_Month = new JComboBox(Bmonth);
        cred_Day =  new JComboBox(Bday);
        
        //Panels are added to all the Frames below.
        panel.add(cred_RoyalBankOfScotlandGroup);
        panel.add(cred_ClientName);
        panel.add(cred_IssuerBank);
        panel.add(cred_GracePeriod);
        panel.add(cred_BalanceAmount);
        panel.add(cred_BankAccount);
        panel.add(cred_InterestRate);
        panel.add(cred_CVCNumber);
        panel.add(cred_ExpirationDate);
        panel.add(cred_CardID);
        panel.add(cred_CreditLimit);
        
        //Panels are added to all the TextField below,
        panel.add(tfieldcred_CardID);
        panel.add(tfieldcred_BankAccount);
        panel.add(tfieldcred_BalanceAmount);
        panel.add(tfieldcred_CVCNumber);
        panel.add(tfieldcred_InterestRate);
        panel.add(tfieldcred_GracePeriod);
        panel.add(tfieldcred_ClientName);
        panel.add(tfieldcred_IssuerBank);
        panel.add(tfieldcred_CreditLimit);
        
        //All Buttons are added to the panel below.
        panel.add(cred_ADDTOCREDITCARD);
        panel.add(cred_CHANGETODEBITCARD);
        panel.add(cred_SETCREDITLIMIT);
        panel.add(cred_CANCELCREDITLIMIT);
        panel.add(cred_CANCEL);
        panel.add(cred_Year);
        panel.add(cred_Month);
        panel.add(cred_Day);
        panel.add(cred_HOME);
        
        //Bounds of the label in the panel are set below.
        cred_RoyalBankOfScotlandGroup.setBounds(237,19,357,73);
        cred_CardID.setBounds(85,221,48,20);
        cred_IssuerBank.setBounds(58,272,89,20);
        cred_BalanceAmount.setBounds(474,119,106,20);
        cred_BankAccount.setBounds(50,176,90,20);
        cred_ClientName.setBounds(50,131,81,20);
        cred_CVCNumber.setBounds(489,221,87,20);
        cred_InterestRate.setBounds(492,170,84,20);
        cred_ExpirationDate.setBounds(450,379,100,20);
        cred_GracePeriod.setBounds(490,272,86,20);
        cred_CreditLimit.setBounds(65,323,75,20);
        
        //Font's weight and size is set below.
        cred_RoyalBankOfScotlandGroup.setFont(new Font("GEORGIA",Font.PLAIN,26));
        
        //Bounds of textfield in the panel is set below,
        tfieldcred_CardID.setBounds(159,215,180,32);
        tfieldcred_IssuerBank.setBounds(156,266,180,32);
        tfieldcred_BankAccount.setBounds(159,164,180,32);
        tfieldcred_BalanceAmount.setBounds(594,113,180,32);
        tfieldcred_ClientName.setBounds(159,119,180,32);
        tfieldcred_CVCNumber.setBounds(594,215,180,32);
        tfieldcred_InterestRate.setBounds(594,164,180,32);
        tfieldcred_GracePeriod.setBounds(594,266,180,32);
        tfieldcred_CreditLimit.setBounds(156,317,180,32);
        
        //Bounds of button in the panel is set below.
        cred_ADDTOCREDITCARD.setBounds(474,317,300,32);
        cred_CHANGETODEBITCARD.setBounds(463,429,311,32);
        cred_SETCREDITLIMIT.setBounds(65,379,120,32);
        cred_CANCELCREDITLIMIT.setBounds(216,379,123,32);
        cred_CANCEL.setBounds(216,458,120,32);
        cred_HOME.setBounds(65,458,120,32);
        
        //Bounds of Combobox in the panel is set below.
        cred_Year.setBounds(553,374,81,32);
        cred_Month.setBounds(642,374,75,32);
        cred_Day.setBounds(725,374,59,32);
        
        //Adding colours 
        panel.setBackground(new Color(244,141,9));
        cred_CardID.setBackground(new Color(29, 0, 33));
        cred_IssuerBank.setBackground(new Color(29, 0, 33));
        cred_BalanceAmount.setBackground(new Color(29,0,33));
        cred_BankAccount.setBackground(new Color(29,0,33));
        cred_SETCREDITLIMIT.setBackground(new Color(23, 244, 9));
        cred_CANCELCREDITLIMIT.setBackground(new Color(241, 63, 63));
        cred_CANCEL.setBackground(new Color(227, 2, 2));
        cred_ADDTOCREDITCARD.setBackground(new Color(23, 244, 9));
        cred_CHANGETODEBITCARD.setBackground(new Color(23, 244, 9));        
       
        
        
        
        panel.setLayout(null);
        frame.add(panel);
        frame.setResizable(false);
        frame.setVisible(true);
        frame.setSize(800,600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
    
    