
/**
 * Write a description of class Debitcard_gui here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.awt.event.*;
import java.awt.*;
import javax.swing.*;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
public class Debitcard_gui
{
   //
   JFrame frame2;
   JPanel panel2;
   //Jlabel are described below.
   JLabel  debt_ClientName,debt_RoyalBankOfScotlandGroup,debt_CardID,debt_IssuerBank,debt_BankAccount,debt_DateOfWithdraw,debt_BalanceAmount,debt_WithDrawAmount,debt_PinNumber;
   
   //Jlabel are described below.
   JTextField  tfielddebt_ClientName,tfielddebt_BalanceAmount,tfielddebt_CardID,tfielddebt_IssuerBank,tfielddebt_BankAccount,tfieldebt_DateOfWithdraw,tfielddebt_WithdrawAmount,tfielddebt_PinNumber;
   
   //JButton are described below.
   JButton debt_ADDTODEBITCARD,debt_WITHDRAWFROMDEBITCARD,debt_CHANGETOCREDITCARD,debt_CANCEL,debt_HOME;
   
   //JCombobox are described below.
   JComboBox debt_Year,debt_Month,debt_Day;
   
   public Debitcard_gui(){
       frame2=new JFrame("Debit Card");
       panel2=new JPanel ();
       frame2.add(panel2);
       
       //frames are added below.
       debt_RoyalBankOfScotlandGroup= new JLabel("Royal Bank of Scotland Group");
       debt_ClientName= new JLabel("Client Name");
       debt_CardID=new JLabel("Card Id");
       debt_IssuerBank=new JLabel("Issuer Bank");
       debt_BankAccount=new JLabel("Bank Account");
       debt_DateOfWithdraw=new JLabel("Date Of Withdraw");
       debt_BalanceAmount=new JLabel("Balance Amount");
       debt_WithDrawAmount=new JLabel("Withdraw Amount");
       debt_PinNumber=new JLabel("Pin Number");
       
       //TextField are added below.
       tfielddebt_ClientName=new JTextField();
       tfielddebt_CardID=new JTextField();
       tfielddebt_IssuerBank=new JTextField();
       tfielddebt_BankAccount=new JTextField();
       tfieldebt_DateOfWithdraw=new JTextField();
       tfielddebt_WithdrawAmount=new JTextField();
       tfielddebt_PinNumber=new JTextField();
       tfielddebt_BalanceAmount=new JTextField();
       
       //JButtons are added below.
       debt_ADDTODEBITCARD=new JButton("Add to Debitcard");
       debt_WITHDRAWFROMDEBITCARD=new JButton("Withdraw from Debit Card");
       debt_CHANGETOCREDITCARD=new JButton("Change to Creditcard");
       debt_CANCEL=new JButton("Cancel");
       debt_HOME=new JButton("Home");
       
       //Integer and String are added to Combobox below.
        Integer Byear[] = {2011,2012,2013,2014,2015,2016,2017,2018,2019,2020,2021,2022,2023};
        String Bmonth[] = {"January","Febuary","March","April","May","June","July","August","September","October",
        "November","December"};
        Integer Bday[] = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30};
        
        debt_Year = new JComboBox(Byear);
        debt_Month = new JComboBox(Bmonth);
        debt_Day =  new JComboBox(Bday);
        
        //Panels are added to all the Frames Below.
        panel2.add(debt_RoyalBankOfScotlandGroup);
        panel2.add(debt_ClientName);
        panel2.add(debt_IssuerBank);
        panel2.add(debt_BalanceAmount);
        panel2.add(debt_BankAccount);
        panel2.add(debt_DateOfWithdraw);
        panel2.add(debt_WithDrawAmount);
        panel2.add(debt_CardID);
        panel2.add(debt_PinNumber);
        
        //Panels are added to all the TextField Below,
        panel2.add(tfielddebt_ClientName);
        panel2.add(tfielddebt_CardID);
        panel2.add(tfielddebt_IssuerBank);
        panel2.add(tfielddebt_BankAccount);
        panel2.add(tfieldebt_DateOfWithdraw);
        panel2.add(tfielddebt_WithdrawAmount);
        panel2.add(tfielddebt_PinNumber);
        panel2.add(tfielddebt_BalanceAmount);
        
        //all buttons are added to the panels Below.
        panel2.add(debt_ADDTODEBITCARD);
        panel2.add(debt_CANCEL);
        panel2.add(debt_WITHDRAWFROMDEBITCARD);
        panel2.add(debt_CHANGETOCREDITCARD);
        panel2.add(debt_HOME);
          
        //Bounds of the label in the panel are Set Below.
        debt_RoyalBankOfScotlandGroup.setBounds(215,13,357,73);
        debt_ClientName.setBounds(22,129,81,20);
        debt_CardID.setBounds(22,187,50,20);
        debt_IssuerBank.setBounds(22,245,78,20);
        debt_BankAccount.setBounds(22,303,90,20);
        debt_DateOfWithdraw.setBounds(394,131,114,20);
        debt_BalanceAmount.setBounds(463,179,106,20);
        debt_WithDrawAmount.setBounds(446,287,114,20);
        debt_PinNumber.setBounds(482,340,78,27);
        
        //Font's weight and size is set below.
       debt_RoyalBankOfScotlandGroup.setFont(new Font("GEORGIA",Font.PLAIN,26));
        
        //Bounds of textfield in the panel is set Below.
        tfielddebt_ClientName.setBounds(119,121,180,32);
        tfielddebt_CardID.setBounds(119,177,180,32);
        tfielddebt_IssuerBank.setBounds(119,233,180,32);
        tfielddebt_BankAccount.setBounds(119,291,180,32);
        tfielddebt_BalanceAmount.setBounds(583,173,180,32);
        tfielddebt_WithdrawAmount.setBounds(583,281,180,32);
        tfielddebt_PinNumber.setBounds(583,333,180,32);
        
        //Bounds of Button in the panel is given Below.
        debt_ADDTODEBITCARD.setBounds(119,358,184,32);
        debt_CANCEL.setBounds(204,430,120,32);
        debt_WITHDRAWFROMDEBITCARD.setBounds(463,227,300,32);
        debt_CHANGETOCREDITCARD.setBounds(466,398,297,32);
        debt_HOME.setBounds(17,430,120,32);
        
        
        //Bounds of ComboBox in the panel is given Below.
        debt_Year.setBounds(514,125,75,26);
        debt_Month.setBounds(603,125,76,26);
        debt_Day.setBounds(695,125,68,26);
        
        //setting Background Colour;
        debt_ADDTODEBITCARD.setBackground(new Color(59, 244, 37));
        panel2.setBackground(new Color(244,141,9));
        debt_CANCEL.setBackground(new Color(231, 31, 52));
        debt_WITHDRAWFROMDEBITCARD.setBackground(new Color(59, 244, 37));
        debt_CHANGETOCREDITCARD.setBackground(new Color(59, 244, 37));
    
        
        
        
        
        
        
        
        
        panel2.setLayout(null);
        frame2.add(panel2);
        frame2.setResizable(false);
        frame2.setVisible(true);
        frame2.setSize(800,600);
        frame2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}

